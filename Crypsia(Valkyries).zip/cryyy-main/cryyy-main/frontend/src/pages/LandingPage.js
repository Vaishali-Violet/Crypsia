import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Shield, Package, Users, TrendingUp, CheckCircle, Lock } from 'lucide-react';

const LandingPage = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Shield className="w-12 h-12" />,
      title: 'procurement Verified',
      description: 'Every transaction recorded on immutable procurement ledger'
    },
    {
      icon: <Package className="w-12 h-12" />,
      title: 'Complete Traceability',
      description: 'Track products from farm to consumer with full transparency'
    },
    {
      icon: <Users className="w-12 h-12" />,
      title: 'Multi-Role Platform',
      description: 'Producers, Regulators, Distributors, Retailers & Consumers'
    },
    {
      icon: <TrendingUp className="w-12 h-12" />,
      title: 'Fair Pricing',
      description: 'Transparent price history at every stage of supply chain'
    },
    {
      icon: <CheckCircle className="w-12 h-12" />,
      title: 'Regulatory Compliance',
      description: 'Verified by certified regulators before marketplace listing'
    },
    {
      icon: <Lock className="w-12 h-12" />,
      title: 'Secure Payments',
      description: 'Smart contract-based escrow and automated payment release'
    }
  ];

  const industries = [
    'Agriculture', 'Textiles', 'Fisheries', 'Exports', 'Food & Beverages', 'Pharmaceuticals'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-emerald-50 to-teal-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-white/80 border-b border-emerald-100">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-emerald-600" />
            <span className="text-2xl font-bold text-gray-900">Crypsia</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={() => navigate('/terms')}
              className="text-gray-700 hover:text-emerald-600"
              data-testid="nav-terms-btn"
            >
              Terms & Conditions
            </Button>
            <Button
              onClick={() => navigate('/auth')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-6"
              data-testid="nav-get-started-btn"
            >
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="container mx-auto text-center max-w-5xl">
          <div className="animate-fade-in">
            <h1 className="text-6xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              procurement-Powered
              <br />
              <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 bg-clip-text text-transparent">
                Supply Chain Transparency
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
              Track every product from producer to consumer with complete transparency.
              Ensure ethical sourcing, verifiable authenticity, and tamper-proof transactions.
            </p>
            <div className="flex items-center justify-center space-x-4">
              <Button
                onClick={() => navigate('/auth')}
                size="lg"
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl"
                data-testid="hero-get-started-btn"
              >
                Get Started Now
              </Button>
              <Button
                onClick={() => navigate('/verify/demo')}
                size="lg"
                variant="outline"
                className="border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50 px-8 py-6 text-lg font-semibold"
                data-testid="hero-demo-btn"
              >
                View Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-white">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Platform Features</h2>
            <p className="text-lg text-gray-600">Everything you need for complete supply chain transparency</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-100 hover:shadow-xl transition-all duration-300 card-hover"
                data-testid={`feature-card-${index}`}
              >
                <div className="text-emerald-600 mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Multi-Industry Support</h2>
            <p className="text-lg text-gray-600">One platform for all supply chain sectors</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {industries.map((industry, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-white border-2 border-emerald-200 hover:border-emerald-400 hover:shadow-lg transition-all duration-300 text-center"
                data-testid={`industry-${index}`}
              >
                <p className="font-semibold text-gray-800">{industry}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-6 bg-gradient-to-br from-emerald-600 to-teal-600 text-white">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">How Crypsia Works</h2>
            <p className="text-lg text-emerald-100">Simple, transparent, and secure</p>
          </div>
          <div className="grid md:grid-cols-5 gap-8">
            <div className="text-center" data-testid="step-producer">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">1</div>
              <h3 className="text-xl font-bold mb-2">Producer</h3>
              <p className="text-emerald-100">Creates & uploads product details</p>
            </div>
            <div className="text-center" data-testid="step-regulator">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">2</div>
              <h3 className="text-xl font-bold mb-2">Regulator</h3>
              <p className="text-emerald-100">Verifies quality & authenticity</p>
            </div>
            <div className="text-center" data-testid="step-distributor">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">3</div>
              <h3 className="text-xl font-bold mb-2">Distributor</h3>
              <p className="text-emerald-100">Purchases & distributes verified goods</p>
            </div>
            <div className="text-center" data-testid="step-retailer">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">4</div>
              <h3 className="text-xl font-bold mb-2">Retailer</h3>
              <p className="text-emerald-100">Sells to consumers with QR codes</p>
            </div>
            <div className="text-center" data-testid="step-consumer">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">5</div>
              <h3 className="text-xl font-bold mb-2">Consumer</h3>
              <p className="text-emerald-100">Buys & verifies full product history</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Ready to Transform Your Supply Chain?</h2>
          <p className="text-xl text-gray-600 mb-10">Join Crypsia today and experience complete transparency</p>
          <Button
            onClick={() => navigate('/auth')}
            size="lg"
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-12 py-6 text-lg font-semibold shadow-lg hover:shadow-xl"
            data-testid="cta-get-started-btn"
          >
            Get Started Free
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-emerald-100 bg-white">
        <div className="container mx-auto text-center text-gray-600">
          <p>&copy; 2025 Crypsia. All rights reserved. Powered by procurement Technology.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
