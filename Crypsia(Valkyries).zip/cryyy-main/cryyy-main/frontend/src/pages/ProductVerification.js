import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { API } from '../App';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Shield, CheckCircle, Package, TrendingUp, ArrowLeft, Clock } from 'lucide-react';
import { toast } from 'sonner';

const ProductVerification = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProductData();
  }, [productId]);

  const fetchProductData = async () => {
    try {
      const response = await axios.get(`${API}/products/${productId}/verify`);
      setData(response.data);
    } catch (error) {
      toast.error('Failed to fetch product data');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'verification':
        return <CheckCircle className="w-6 h-6 text-blue-600" />;
      case 'purchase':
        return <TrendingUp className="w-6 h-6 text-green-600" />;
      case 'price_update':
        return <Package className="w-6 h-6 text-purple-600" />;
      default:
        return <Package className="w-6 h-6 text-gray-600" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-emerald-600 mx-auto mb-4 animate-pulse" />
          <p className="text-xl text-gray-700">Verifying product on procurement...</p>
        </div>
      </div>
    );
  }

  if (!data || !data.product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h2>
          <p className="text-gray-600 mb-6">The product ID you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => navigate('/')} className="bg-emerald-600 hover:bg-emerald-700">
            Go to Homepage
          </Button>
        </Card>
      </div>
    );
  }

  const { product, procurement_history, verified } = data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 py-12 px-6">
      <div className="container mx-auto max-w-6xl">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6 text-emerald-600 hover:text-emerald-700"
          data-testid="back-button"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        {/* Product Overview */}
        <Card className="p-8 mb-8 bg-white">
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">{product.name}</h1>
              <p className="text-lg text-gray-600">{product.product_type}</p>
            </div>
            <div className="text-center">
              {verified ? (
                <div className="flex flex-col items-center">
                  <CheckCircle className="w-16 h-16 text-green-600 mb-2" />
                  <span className="px-4 py-2 bg-green-100 text-green-700 font-semibold rounded-full">
                    Verified ✓
                  </span>
                </div>
              ) : (
                <span className="px-4 py-2 bg-yellow-100 text-yellow-700 font-semibold rounded-full">
                  Pending Verification
                </span>
              )}
            </div>
          </div>

          <p className="text-gray-700 mb-6">{product.description}</p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Producer</p>
              <p className="font-bold text-gray-900">{product.producer_name}</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Quantity</p>
              <p className="font-bold text-gray-900">{product.quantity} {product.unit}</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Quality Grade</p>
              <p className="font-bold text-gray-900">Grade {product.quality_grade}</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Current Price</p>
              <p className="font-bold text-emerald-600 text-2xl">${product.current_price}</p>
            </div>
          </div>
        </Card>

        {/* procurement History */}
        <Card className="p-8 bg-white">
          <div className="flex items-center mb-6">
            <Shield className="w-8 h-8 text-emerald-600 mr-3" />
            <h2 className="text-3xl font-bold text-gray-900">procurement Transaction History</h2>
          </div>
          <p className="text-gray-600 mb-8">Complete immutable record of product journey from producer to current owner</p>

          {procurement_history.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No procurement transactions yet. Product is awaiting verification.</p>
            </div>
          ) : (
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-8 top-8 bottom-8 w-0.5 bg-emerald-200"></div>

              <div className="space-y-8">
                {procurement_history.map((tx, index) => (
                  <div key={tx.id} className="relative pl-20" data-testid={`procurement-tx-${index}`}>
                    {/* Timeline dot */}
                    <div className="absolute left-5 top-2 w-6 h-6 bg-emerald-600 rounded-full border-4 border-white shadow-lg flex items-center justify-center">
                      {getTransactionIcon(tx.transaction_type)}
                    </div>

                    <Card className="p-6 bg-gradient-to-r from-white to-emerald-50 border-l-4 border-emerald-600">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 mb-1 capitalize">
                            {tx.transaction_type.replace('_', ' ')}
                          </h3>
                          <p className="text-sm text-gray-600">{formatDate(tx.timestamp)}</p>
                        </div>
                        {tx.amount > 0 && (
                          <div className="text-right">
                            <p className="text-sm text-gray-600">Amount</p>
                            <p className="text-2xl font-bold text-emerald-600">${tx.amount.toFixed(2)}</p>
                          </div>
                        )}
                      </div>

                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-xs text-gray-500 mb-1">From</p>
                          <p className="font-semibold text-gray-900">{tx.from_user_name}</p>
                          <p className="text-xs text-gray-600 capitalize">({tx.from_user_role})</p>
                        </div>
                        {tx.to_user_name && (
                          <div>
                            <p className="text-xs text-gray-500 mb-1">To</p>
                            <p className="font-semibold text-gray-900">{tx.to_user_name}</p>
                            <p className="text-xs text-gray-600 capitalize">({tx.to_user_role})</p>
                          </div>
                        )}
                      </div>

                      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                        <p className="text-xs text-gray-500 mb-1">Transaction Hash (SHA-256)</p>
                        <p className="hash-text font-mono text-xs break-all">{tx.transaction_hash}</p>
                        {tx.previous_hash && (
                          <>
                            <p className="text-xs text-gray-500 mt-3 mb-1">Previous Hash</p>
                            <p className="hash-text font-mono text-xs break-all">{tx.previous_hash}</p>
                          </>
                        )}
                      </div>

                      {tx.metadata && Object.keys(tx.metadata).length > 0 && (
                        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <p className="text-xs text-gray-600 font-semibold mb-2">Additional Details:</p>
                          <div className="text-xs space-y-1">
                            {Object.entries(tx.metadata).map(([key, value]) => (
                              <div key={key} className="flex justify-between">
                                <span className="text-gray-600 capitalize">{key.replace('_', ' ')}:</span>
                                <span className="font-semibold">{JSON.stringify(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </Card>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>

        {/* Trust Indicators */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Card className="p-6 text-center bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <Shield className="w-12 h-12 text-blue-600 mx-auto mb-3" />
            <h3 className="font-bold text-gray-900 mb-2">procurement Secured</h3>
            <p className="text-sm text-gray-700">All transactions cryptographically hashed and immutable</p>
          </Card>
          <Card className="p-6 text-center bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
            <h3 className="font-bold text-gray-900 mb-2">Regulator Verified</h3>
            <p className="text-sm text-gray-700">Quality and authenticity certified by authorities</p>
          </Card>
          <Card className="p-6 text-center bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <TrendingUp className="w-12 h-12 text-purple-600 mx-auto mb-3" />
            <h3 className="font-bold text-gray-900 mb-2">Complete Traceability</h3>
            <p className="text-sm text-gray-700">Full transparency from producer to current owner</p>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ProductVerification;
