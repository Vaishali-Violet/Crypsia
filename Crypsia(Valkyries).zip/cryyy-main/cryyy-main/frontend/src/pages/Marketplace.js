import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { API } from '../App';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { toast } from 'sonner';
import { Shield, ArrowLeft, Package, ShoppingCart, Wallet, LogOut } from 'lucide-react';

const Marketplace = ({ user, token, onLogout }) => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(null);

  const axiosConfig = {
    headers: { Authorization: `Bearer ${token}` }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/marketplace/products`, axiosConfig);
      setProducts(response.data);
    } catch (error) {
      toast.error('Failed to fetch marketplace products');
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (product) => {
    if (user.wallet_balance < product.current_price) {
      toast.error('Insufficient wallet balance');
      return;
    }

    setPurchasing(product.id);
    try {
      await axios.post(`${API}/marketplace/purchase`, {
        product_id: product.id,
        buyer_role: user.role
      }, axiosConfig);
      toast.success('Purchase successful! Product added to your inventory.');
      fetchProducts();
      // Refresh user wallet balance
      window.location.reload();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Purchase failed');
    } finally {
      setPurchasing(null);
    }
  };

  const getRoleTitle = () => {
    switch (user.role) {
      case 'distributor':
        return 'Purchase from Producers';
      case 'retailer':
        return 'Purchase from Distributors';
      case 'consumer':
        return 'Shop from Retailers';
      default:
        return 'Marketplace';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <Shield className="w-8 h-8 text-emerald-600" />
                <span className="text-2xl font-bold text-gray-900">Crypsia</span>
              </div>
              <div className="hidden md:flex items-center space-x-1">
                <Button
                  variant="ghost"
                  onClick={() => navigate('/dashboard')}
                  className="text-gray-700 hover:text-emerald-600"
                  data-testid="nav-dashboard-btn"
                >
                  Dashboard
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => navigate('/marketplace')}
                  className="text-emerald-600"
                  data-testid="nav-marketplace-btn"
                >
                  Marketplace
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => navigate('/transactions')}
                  className="text-gray-700 hover:text-emerald-600"
                  data-testid="nav-transactions-btn"
                >
                  Transactions
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-4 py-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <Wallet className="w-5 h-5 text-emerald-600" />
                <span className="font-semibold text-emerald-700" data-testid="wallet-balance">
                  ${user.wallet_balance?.toFixed(2) || '0.00'}
                </span>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-gray-900">{user.full_name}</p>
                <p className="text-xs text-gray-500 capitalize">{user.role}</p>
              </div>
              <Button
                variant="outline"
                onClick={onLogout}
                className="border-red-200 text-red-600 hover:bg-red-50"
                data-testid="logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">{getRoleTitle()}</h1>
          <p className="text-lg text-gray-600">All products are procurement-verified and traceable</p>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">Loading products...</p>
          </div>
        ) : products.length === 0 ? (
          <Card className="p-12 text-center">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">No products available at the moment.</p>
            <p className="text-gray-500 text-sm mt-2">Check back later for new listings!</p>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="p-6 hover:shadow-xl transition-all duration-300" data-testid={`product-${product.id}`}>
                <div className="mb-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{product.name}</h3>
                    <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                      Verified
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{product.product_type}</p>
                </div>

                <p className="text-gray-700 text-sm mb-4 line-clamp-2">{product.description}</p>

                <div className="space-y-2 mb-4 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Producer:</span>
                    <span className="font-semibold">{product.producer_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Quantity:</span>
                    <span className="font-semibold">{product.quantity} {product.unit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Quality:</span>
                    <span className="font-semibold">Grade {product.quality_grade}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                    <span className="text-gray-600 font-semibold">Price:</span>
                    <span className="text-2xl font-bold text-emerald-600">${product.current_price}</span>
                  </div>
                </div>

                <Button
                  onClick={() => handlePurchase(product)}
                  disabled={purchasing === product.id || user.wallet_balance < product.current_price}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white disabled:bg-gray-300"
                  data-testid={`purchase-${product.id}`}
                >
                  {purchasing === product.id ? (
                    'Processing...'
                  ) : user.wallet_balance < product.current_price ? (
                    'Insufficient Balance'
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Purchase Now
                    </>
                  )}
                </Button>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Marketplace;
