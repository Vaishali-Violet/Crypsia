import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { API } from '../App';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { toast } from 'sonner';
import { Shield, Package, TrendingUp, Wallet, Plus, Edit, Trash2, CheckCircle, XCircle, ShoppingCart, DollarSign, LogOut, FileText, BarChart } from 'lucide-react';
import ProducerDashboard from '../components/ProducerDashboard';
import RegulatorDashboard from '../components/RegulatorDashboard';
import DistributorDashboard from '../components/DistributorDashboard';
import RetailerDashboard from '../components/RetailerDashboard';
import ConsumerDashboard from '../components/ConsumerDashboard';

const Dashboard = ({ user, token, onLogout }) => {
  const navigate = useNavigate();
  const [analytics, setAnalytics] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${API}/analytics/dashboard`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAnalytics(response.data);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const axiosConfig = {
    headers: { Authorization: `Bearer ${token}` }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <Shield className="w-8 h-8 text-emerald-600" />
                <span className="text-2xl font-bold text-gray-900">Crypsia</span>
              </div>
              <div className="hidden md:flex items-center space-x-1">
                <Button
                  variant="ghost"
                  onClick={() => navigate('/dashboard')}
                  className="text-gray-700 hover:text-emerald-600"
                  data-testid="nav-dashboard-btn"
                >
                  Dashboard
                </Button>
                {user.role !== 'consumer' && (
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/marketplace')}
                    className="text-gray-700 hover:text-emerald-600"
                    data-testid="nav-marketplace-btn"
                  >
                    Marketplace
                  </Button>
                )}
                {user.role === 'consumer' && (
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/marketplace')}
                    className="text-gray-700 hover:text-emerald-600"
                    data-testid="nav-shop-btn"
                  >
                    Shop
                  </Button>
                )}
                <Button
                  variant="ghost"
                  onClick={() => navigate('/transactions')}
                  className="text-gray-700 hover:text-emerald-600"
                  data-testid="nav-transactions-btn"
                >
                  Transactions
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-4 py-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <Wallet className="w-5 h-5 text-emerald-600" />
                <span className="font-semibold text-emerald-700" data-testid="wallet-balance">
                  ${user.wallet_balance?.toFixed(2) || '0.00'}
                </span>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-gray-900" data-testid="user-name">{user.full_name}</p>
                <p className="text-xs text-gray-500 capitalize" data-testid="user-role">{user.role}</p>
              </div>
              <Button
                variant="outline"
                onClick={onLogout}
                className="border-red-200 text-red-600 hover:bg-red-50"
                data-testid="logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        {/* Analytics Cards */}
        {!loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {Object.keys(analytics).map((key, index) => (
              <Card key={index} className="p-6 bg-white border border-gray-200 hover:shadow-lg transition-shadow" data-testid={`analytics-card-${index}`}>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-gray-600 capitalize">{key.replace(/_/g, ' ')}</p>
                  {key.includes('wallet') && <Wallet className="w-5 h-5 text-emerald-600" />}
                  {key.includes('revenue') && <TrendingUp className="w-5 h-5 text-green-600" />}
                  {key.includes('products') && <Package className="w-5 h-5 text-blue-600" />}
                </div>
                <p className="text-3xl font-bold text-gray-900">
                  {typeof analytics[key] === 'number' && key.toLowerCase().includes('balance') || key.toLowerCase().includes('revenue') || key.toLowerCase().includes('spent') || key.toLowerCase().includes('profit')
                    ? `$${analytics[key].toFixed(2)}`
                    : analytics[key]}
                </p>
              </Card>
            ))}
          </div>
        )}

        {/* Role-Specific Dashboard */}
        {user.role === 'producer' && <ProducerDashboard user={user} token={token} axiosConfig={axiosConfig} />}
        {user.role === 'regulator' && <RegulatorDashboard user={user} token={token} axiosConfig={axiosConfig} />}
        {user.role === 'distributor' && <DistributorDashboard user={user} token={token} axiosConfig={axiosConfig} />}
        {user.role === 'retailer' && <RetailerDashboard user={user} token={token} axiosConfig={axiosConfig} />}
        {user.role === 'consumer' && <ConsumerDashboard user={user} token={token} axiosConfig={axiosConfig} />}
      </div>
    </div>
  );
};

export default Dashboard;
