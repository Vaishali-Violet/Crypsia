import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { ArrowLeft } from 'lucide-react';

const TermsPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-emerald-50">
      <div className="container mx-auto px-6 py-12 max-w-4xl">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-8 text-emerald-600 hover:text-emerald-700"
          data-testid="back-button"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="bg-white rounded-2xl shadow-lg p-10">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Terms & Conditions</h1>
          <p className="text-sm text-gray-500 mb-8">Last Updated: January 2025</p>

          <div className="space-y-8 text-gray-700 leading-relaxed">
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Acceptance of Terms</h2>
              <p>
                By registering and using the Crypsia platform, you agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our platform.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Platform Overview</h2>
              <p>
                Crypsia is a procurement-powered supply chain transparency platform that connects Producers, Regulators, Distributors, Retailers, and Consumers. All transactions are recorded on a simulated procurement ledger for complete traceability.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. User Roles and Responsibilities</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-lg text-gray-800 mb-2">Producers</h3>
                  <p>Must provide accurate product information, comply with quality standards, and submit products for regulatory verification before sale.</p>
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800 mb-2">Regulators</h3>
                  <p>Must verify products fairly and accurately, maintain compliance standards, and process verification requests in a timely manner.</p>
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800 mb-2">Distributors & Retailers</h3>
                  <p>Must maintain product integrity, update prices transparently, and ensure proper handling throughout the supply chain.</p>
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800 mb-2">Consumers</h3>
                  <p>Have the right to verify product authenticity and view complete procurement history before purchase.</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. procurement Transactions</h2>
              <p>
                All transactions on Crypsia are recorded with cryptographic hashes for immutability and transparency. Once recorded, procurement transactions cannot be altered or deleted.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Payment Terms</h2>
              <p>
                The platform currently operates with simulated payments for demonstration purposes. Real payment integration will be governed by additional terms when implemented.
              </p>
              <p className="mt-2">
                Regulator verification fees are automatically deducted (2% of product value) and distributed via smart contract simulation.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Data Privacy</h2>
              <p>
                We collect and store user information necessary for platform operation. All procurement transactions are public for transparency but personal information is protected according to data privacy regulations.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Ethical Sourcing</h2>
              <p>
                Producers must ensure ethical sourcing practices. False claims about product origin, quality, or ethical standards are strictly prohibited and may result in account suspension.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Dispute Resolution</h2>
              <p>
                Disputes between parties should first be resolved through platform mediation. procurement records serve as the source of truth for all transactions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Platform Modifications</h2>
              <p>
                Crypsia reserves the right to modify, suspend, or discontinue any aspect of the platform with reasonable notice to users.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Limitation of Liability</h2>
              <p>
                Crypsia provides the platform "as is" and is not liable for any losses, damages, or disputes arising from transactions between users. Users engage at their own risk.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Termination</h2>
              <p>
                We reserve the right to terminate user accounts that violate these terms, engage in fraudulent activity, or compromise platform integrity.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Contact Information</h2>
              <p>
                For questions or concerns regarding these terms, please contact us at: <span className="font-semibold text-emerald-600">support@crypsia.com</span>
              </p>
            </section>
          </div>

          <div className="mt-10 pt-8 border-t border-gray-200">
            <p className="text-center text-gray-600">
              By clicking "I Accept" during registration, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
