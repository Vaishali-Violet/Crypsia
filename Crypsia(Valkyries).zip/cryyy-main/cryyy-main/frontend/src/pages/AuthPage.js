import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { API } from '../App';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { toast } from 'sonner';
import { Shield, ArrowLeft } from 'lucide-react';

const AuthPage = ({ onLogin }) => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  
  // Login form
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });
  
  // Register form
  const [registerData, setRegisterData] = useState({
    email: '',
    password: '',
    full_name: '',
    role: 'producer',
    contact: '',
    location: '',
    product_type: '',
    payment_info: '',
    terms_accepted: false
  });

  const roles = [
    { value: 'producer', label: 'Producer (Farmer/Manufacturer)' },
    { value: 'regulator', label: 'Regulator (Verification Authority)' },
    { value: 'distributor', label: 'Distributor (Wholesale Buyer)' },
    { value: 'retailer', label: 'Retailer (Store Owner)' },
    { value: 'consumer', label: 'Consumer (End User)' }
  ];

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post(`${API}/auth/login`, loginData);
      toast.success('Login successful!');
      onLogin(response.data.token, response.data.user);
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    
    if (!registerData.terms_accepted) {
      toast.error('Please accept the terms and conditions');
      return;
    }
    
    setLoading(true);
    try {
      const response = await axios.post(`${API}/auth/register`, registerData);
      toast.success('Registration successful!');
      onLogin(response.data.token, response.data.user);
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-100 flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-6 text-emerald-600 hover:text-emerald-700"
          data-testid="back-to-home-btn"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-8 text-white text-center">
            <Shield className="w-16 h-16 mx-auto mb-4" />
            <h1 className="text-3xl font-bold mb-2">Welcome to Crypsia</h1>
            <p className="text-emerald-100">procurement Supply Chain Transparency Platform</p>
          </div>

          {/* Toggle Buttons */}
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-4 font-semibold transition-colors ${
                isLogin ? 'bg-white text-emerald-600 border-b-2 border-emerald-600' : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
              data-testid="login-tab"
            >
              Login
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-4 font-semibold transition-colors ${
                !isLogin ? 'bg-white text-emerald-600 border-b-2 border-emerald-600' : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
              data-testid="register-tab"
            >
              Register
            </button>
          </div>

          {/* Forms */}
          <div className="p-8">
            {isLogin ? (
              <form onSubmit={handleLogin} className="space-y-6" data-testid="login-form">
                <div>
                  <Label htmlFor="login-email" className="text-gray-700 font-semibold">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                    required
                    className="mt-2 border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                    placeholder="your@email.com"
                    data-testid="login-email-input"
                  />
                </div>
                <div>
                  <Label htmlFor="login-password" className="text-gray-700 font-semibold">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    required
                    className="mt-2 border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                    placeholder="Enter your password"
                    data-testid="login-password-input"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-6 text-lg font-semibold"
                  data-testid="login-submit-btn"
                >
                  {loading ? 'Logging in...' : 'Login'}
                </Button>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="space-y-5" data-testid="register-form">
                <div>
                  <Label htmlFor="role" className="text-gray-700 font-semibold">Select Your Role</Label>
                  <select
                    id="role"
                    value={registerData.role}
                    onChange={(e) => setRegisterData({ ...registerData, role: e.target.value })}
                    className="mt-2 w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none"
                    data-testid="register-role-select"
                  >
                    {roles.map((role) => (
                      <option key={role.value} value={role.value}>
                        {role.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="full-name" className="text-gray-700 font-semibold">Full Name</Label>
                    <Input
                      id="full-name"
                      type="text"
                      value={registerData.full_name}
                      onChange={(e) => setRegisterData({ ...registerData, full_name: e.target.value })}
                      required
                      className="mt-2 border-gray-300 focus:border-emerald-500"
                      placeholder="John Doe"
                      data-testid="register-name-input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-gray-700 font-semibold">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      required
                      className="mt-2 border-gray-300 focus:border-emerald-500"
                      placeholder="your@email.com"
                      data-testid="register-email-input"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="password" className="text-gray-700 font-semibold">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      required
                      className="mt-2 border-gray-300 focus:border-emerald-500"
                      placeholder="Secure password"
                      data-testid="register-password-input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact" className="text-gray-700 font-semibold">Contact Number</Label>
                    <Input
                      id="contact"
                      type="tel"
                      value={registerData.contact}
                      onChange={(e) => setRegisterData({ ...registerData, contact: e.target.value })}
                      required
                      className="mt-2 border-gray-300 focus:border-emerald-500"
                      placeholder="+1234567890"
                      data-testid="register-contact-input"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="location" className="text-gray-700 font-semibold">Location / Address</Label>
                  <Input
                    id="location"
                    type="text"
                    value={registerData.location}
                    onChange={(e) => setRegisterData({ ...registerData, location: e.target.value })}
                    className="mt-2 border-gray-300 focus:border-emerald-500"
                    placeholder="City, State, Country"
                    data-testid="register-location-input"
                  />
                </div>

                {registerData.role === 'producer' && (
                  <div>
                    <Label htmlFor="product-type" className="text-gray-700 font-semibold">Product Type</Label>
                    <Input
                      id="product-type"
                      type="text"
                      value={registerData.product_type}
                      onChange={(e) => setRegisterData({ ...registerData, product_type: e.target.value })}
                      className="mt-2 border-gray-300 focus:border-emerald-500"
                      placeholder="e.g., Organic Vegetables, Textiles"
                      data-testid="register-product-type-input"
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="payment-info" className="text-gray-700 font-semibold">Payment Info (Bank/UPI/Wallet)</Label>
                  <Input
                    id="payment-info"
                    type="text"
                    value={registerData.payment_info}
                    onChange={(e) => setRegisterData({ ...registerData, payment_info: e.target.value })}
                    className="mt-2 border-gray-300 focus:border-emerald-500"
                    placeholder="Bank account or UPI ID"
                    data-testid="register-payment-input"
                  />
                </div>

                <div className="flex items-start space-x-3 p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                  <Checkbox
                    id="terms"
                    checked={registerData.terms_accepted}
                    onCheckedChange={(checked) => setRegisterData({ ...registerData, terms_accepted: checked })}
                    className="mt-1"
                    data-testid="register-terms-checkbox"
                  />
                  <Label htmlFor="terms" className="text-sm text-gray-700 leading-relaxed cursor-pointer">
                    I accept the{' '}
                    <button
                      type="button"
                      onClick={() => window.open('/terms', '_blank')}
                      className="text-emerald-600 font-semibold hover:underline"
                    >
                      Terms & Conditions
                    </button>
                    {' '}and agree to ethical sourcing, regulatory compliance, and transparent transactions.
                  </Label>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-6 text-lg font-semibold"
                  data-testid="register-submit-btn"
                >
                  {loading ? 'Creating Account...' : 'Create Account'}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
