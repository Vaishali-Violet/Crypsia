import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { API } from '../App';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Shield, Wallet, LogOut, FileText, Filter } from 'lucide-react';
import { toast } from 'sonner';

const TransactionLedger = ({ user, token, onLogout }) => {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const axiosConfig = {
    headers: { Authorization: `Bearer ${token}` }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  useEffect(() => {
    applyFilter();
  }, [filter, transactions]);

  const fetchTransactions = async () => {
    try {
      const endpoint = filter === 'my' ? '/transactions/my-transactions' : '/transactions';
      const response = await axios.get(`${API}${endpoint}`, axiosConfig);
      setTransactions(response.data);
    } catch (error) {
      toast.error('Failed to fetch transactions');
    } finally {
      setLoading(false);
    }
  };

  const applyFilter = () => {
    if (filter === 'my') {
      const myTransactions = transactions.filter(
        tx => tx.from_user_id === user.id || tx.to_user_id === user.id
      );
      setFilteredTransactions(myTransactions);
    } else {
      setFilteredTransactions(transactions);
    }
  };

  const getTransactionTypeColor = (type) => {
    switch (type) {
      case 'verification':
        return 'bg-blue-100 text-blue-700';
      case 'purchase':
        return 'bg-green-100 text-green-700';
      case 'price_update':
        return 'bg-purple-100 text-purple-700';
      case 'transfer':
        return 'bg-orange-100 text-orange-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <Shield className="w-8 h-8 text-emerald-600" />
                <span className="text-2xl font-bold text-gray-900">Crypsia</span>
              </div>
              <div className="hidden md:flex items-center space-x-1">
                <Button
                  variant="ghost"
                  onClick={() => navigate('/dashboard')}
                  className="text-gray-700 hover:text-emerald-600"
                  data-testid="nav-dashboard-btn"
                >
                  Dashboard
                </Button>
                {user.role !== 'consumer' && (
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/marketplace')}
                    className="text-gray-700 hover:text-emerald-600"
                    data-testid="nav-marketplace-btn"
                  >
                    Marketplace
                  </Button>
                )}
                {user.role === 'consumer' && (
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/marketplace')}
                    className="text-gray-700 hover:text-emerald-600"
                    data-testid="nav-shop-btn"
                  >
                    Shop
                  </Button>
                )}
                <Button
                  variant="ghost"
                  onClick={() => navigate('/transactions')}
                  className="text-emerald-600"
                  data-testid="nav-transactions-btn"
                >
                  Transactions
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-4 py-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <Wallet className="w-5 h-5 text-emerald-600" />
                <span className="font-semibold text-emerald-700" data-testid="wallet-balance">
                  ${user.wallet_balance?.toFixed(2) || '0.00'}
                </span>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-gray-900">{user.full_name}</p>
                <p className="text-xs text-gray-500 capitalize">{user.role}</p>
              </div>
              <Button
                variant="outline"
                onClick={onLogout}
                className="border-red-200 text-red-600 hover:bg-red-50"
                data-testid="logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">procurement Transaction Ledger</h1>
              <p className="text-lg text-gray-600">Complete immutable record of all supply chain transactions</p>
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={() => setFilter('all')}
                variant={filter === 'all' ? 'default' : 'outline'}
                className={filter === 'all' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                data-testid="filter-all-btn"
              >
                All Transactions
              </Button>
              <Button
                onClick={() => setFilter('my')}
                variant={filter === 'my' ? 'default' : 'outline'}
                className={filter === 'my' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                data-testid="filter-my-btn"
              >
                My Transactions
              </Button>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">Loading transactions...</p>
          </div>
        ) : filteredTransactions.length === 0 ? (
          <Card className="p-12 text-center">
            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">No transactions found.</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredTransactions.map((tx) => (
              <Card key={tx.id} className="p-6 hover:shadow-lg transition-shadow" data-testid={`transaction-${tx.id}`}>
                <div className="grid md:grid-cols-5 gap-6">
                  <div className="md:col-span-2">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getTransactionTypeColor(tx.transaction_type)}`}>
                        {tx.transaction_type.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-1"><strong>Product:</strong> {tx.product_name}</p>
                    <p className="text-sm text-gray-600"><strong>Date:</strong> {formatDate(tx.timestamp)}</p>
                  </div>

                  <div className="md:col-span-2">
                    <div className="space-y-2">
                      <div>
                        <p className="text-xs text-gray-500">From</p>
                        <p className="text-sm font-semibold text-gray-900">{tx.from_user_name}</p>
                        <p className="text-xs text-gray-600 capitalize">({tx.from_user_role})</p>
                      </div>
                      {tx.to_user_name && (
                        <div>
                          <p className="text-xs text-gray-500">To</p>
                          <p className="text-sm font-semibold text-gray-900">{tx.to_user_name}</p>
                          <p className="text-xs text-gray-600 capitalize">({tx.to_user_role})</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    {tx.amount > 0 && (
                      <p className="text-2xl font-bold text-emerald-600 mb-2">${tx.amount.toFixed(2)}</p>
                    )}
                    <p className="text-xs text-gray-500 mb-1">Transaction Hash</p>
                    <p className="hash-text text-xs">{tx.transaction_hash.substring(0, 16)}...</p>
                    {tx.previous_hash && (
                      <>
                        <p className="text-xs text-gray-500 mt-2 mb-1">Previous Hash</p>
                        <p className="hash-text text-xs">{tx.previous_hash.substring(0, 16)}...</p>
                      </>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionLedger;
