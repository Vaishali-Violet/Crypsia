import { useState, useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import axios from "axios";
import LandingPage from "./pages/LandingPage";
import AuthPage from "./pages/AuthPage";
import Dashboard from "./pages/Dashboard";
import Marketplace from "./pages/Marketplace";
import TransactionLedger from "./pages/TransactionLedger";
import ProductVerification from "./pages/ProductVerification";
import TermsPage from "./pages/TermsPage";
import { Toaster } from "./components/ui/sonner";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
export const API = `${BACKEND_URL}/api`;

function App() {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      if (token) {
        try {
          const response = await axios.get(`${API}/auth/me`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          setUser(response.data);
        } catch (error) {
          console.error("Failed to fetch user:", error);
          localStorage.removeItem("token");
          setToken(null);
        }
      }
      setLoading(false);
    };

    fetchUser();
  }, [token]);

  const handleLogin = (newToken, userData) => {
    localStorage.setItem("token", newToken);
    setToken(newToken);
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-teal-100">
        <div className="text-2xl font-semibold text-emerald-700">Loading...</div>
      </div>
    );
  }

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={user ? <Navigate to="/dashboard" /> : <LandingPage />} />
          <Route
            path="/auth"
            element={user ? <Navigate to="/dashboard" /> : <AuthPage onLogin={handleLogin} />}
          />
          <Route path="/terms" element={<TermsPage />} />
          <Route
            path="/dashboard"
            element={user ? <Dashboard user={user} token={token} onLogout={handleLogout} /> : <Navigate to="/auth" />}
          />
          <Route
            path="/marketplace"
            element={user ? <Marketplace user={user} token={token} onLogout={handleLogout} /> : <Navigate to="/auth" />}
          />
          <Route
            path="/transactions"
            element={user ? <TransactionLedger user={user} token={token} onLogout={handleLogout} /> : <Navigate to="/auth" />}
          />
          <Route
            path="/verify/:productId"
            element={<ProductVerification />}
          />
        </Routes>
      </BrowserRouter>
      <Toaster position="top-right" />
    </div>
  );
}

export default App;
