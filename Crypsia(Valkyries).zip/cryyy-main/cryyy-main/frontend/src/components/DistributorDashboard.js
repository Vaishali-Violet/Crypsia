import { useState, useEffect } from 'react';
import axios from 'axios';
import { API } from '../App';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner';
import { Package, DollarSign } from 'lucide-react';

const DistributorDashboard = ({ user, token, axiosConfig }) => {
  const [myProducts, setMyProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showPriceDialog, setShowPriceDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [newPrice, setNewPrice] = useState('');

  useEffect(() => {
    fetchMarketplaceProducts();
  }, []);

  // ✅ Fetch products from marketplace
  const fetchMarketplaceProducts = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${API}/marketplace/products`,
        axiosConfig
      );
      setMyProducts(response.data);
    } catch (error) {
      toast.error('Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePrice = (product) => {
    setSelectedProduct(product);
    setNewPrice((product.current_price || 0).toString());
    setShowPriceDialog(true);
  };

  const submitPriceUpdate = async () => {
    try {
      await axios.post(
        `${API}/marketplace/update-price`,
        {
          product_id: selectedProduct.id,
          new_price: parseFloat(newPrice),
        },
        axiosConfig
      );

      toast.success('Price updated successfully');
      setShowPriceDialog(false);
      fetchMarketplaceProducts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to update price');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">My Inventory</h2>

      {loading ? (
        <p className="text-center text-gray-600">Loading inventory...</p>
      ) : myProducts.length === 0 ? (
        <Card className="p-12 text-center">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 text-lg">
            No products in inventory. Visit the marketplace to purchase!
          </p>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {myProducts.map((product) => (
            <Card
              key={product.id}
              className="p-6 hover:shadow-lg transition-shadow"
              data-testid={`product-${product.id}`}
            >
              <h3 className="text-xl font-bold text-gray-900 mb-1">
                {product.name}
              </h3>

              {/* Product ID */}
              <p className="text-xs text-gray-500 mb-3 font-mono">
                Product ID: {product.product_id || product.id}
              </p>

              <div className="space-y-2 mb-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Producer:</span>
                  <span className="font-semibold">{product.producer_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Type:</span>
                  <span className="font-semibold">{product.product_type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Quantity:</span>
                  <span className="font-semibold">
                    {product.quantity} {product.unit}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Current Price:</span>
                  <span className="font-semibold text-emerald-600">
                    ${product.current_price}
                  </span>
                </div>
              </div>

              <Button
                onClick={() => handleUpdatePrice(product)}
                className="w-full bg-blue-600 hover:bg-blue-700"
                data-testid={`update-price-${product.id}`}
              >
                <DollarSign className="w-4 h-4 mr-2" />
                Update Price for Resale
              </Button>
            </Card>
          ))}
        </div>
      )}

      {/* Price Update Modal */}
      <Dialog open={showPriceDialog} onOpenChange={setShowPriceDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Product Price</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-gray-700">
              Set a new price for <strong>{selectedProduct?.name}</strong> to
              sell to retailers.
            </p>

            <div>
              <Label htmlFor="new-price">New Price ($)</Label>
              <Input
                id="new-price"
                type="number"
                step="0.01"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                data-testid="new-price-input"
              />
            </div>

            <div className="flex space-x-3">
              <Button
                onClick={submitPriceUpdate}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                data-testid="submit-price-btn"
              >
                Update Price
              </Button>

              <Button
                onClick={() => setShowPriceDialog(false)}
                variant="outline"
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DistributorDashboard;
