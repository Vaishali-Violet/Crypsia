import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';

const ConsumerDashboard = ({ user }) => {
  const navigate = useNavigate();
  const [productId, setProductId] = useState('');

  const handleVerify = () => {
    if (!productId.trim()) {
      toast.error('Please enter a product ID');
      return;
    }
    navigate(`/verify/${productId.trim()}`);
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-50 p-4 space-y-12">

      {/* Welcome Section */}
      <div className="text-center max-w-3xl">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome, {user.full_name}!
        </h2>
        <p className="text-lg text-gray-600">
          Shop for verified products and scan QR codes to view complete procurement history from producer to retailer.
        </p>
      </div>

      {/* Browse Products Card */}
      <Card className="p-8 text-center hover:shadow-xl transition-shadow flex flex-col items-center justify-center">
        <ShoppingBag className="w-16 h-16 text-emerald-600 mb-4" />
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Browse Products</h3>
        <p className="text-gray-600 mb-6 text-center max-w-xs">
          Explore verified products from trusted retailers with complete transparency.
        </p>
        <Button
          onClick={() => navigate('/marketplace')}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-6 text-lg"
        >
          Start Shopping
        </Button>
      </Card>

      {/* Transparency Section */}
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-8 max-w-4xl mx-auto border border-emerald-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">
          Why Procurement Transparency Matters
        </h3>

        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-bold text-emerald-700 mb-2">Authenticity Verified</h4>
            <p className="text-sm text-gray-700">
              Every product is verified by regulators before reaching you.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-emerald-700 mb-2">Complete Traceability</h4>
            <p className="text-sm text-gray-700">
              Track the entire journey from producer to your hands.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-emerald-700 mb-2">Fair Pricing</h4>
            <p className="text-sm text-gray-700">
              See transparent price history at every supply chain stage.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};

export default ConsumerDashboard;
