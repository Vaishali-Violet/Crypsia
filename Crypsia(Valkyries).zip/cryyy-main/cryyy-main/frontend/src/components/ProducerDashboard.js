import { useState, useEffect } from 'react';
import axios from 'axios';
import { API } from '../App';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Send, Package } from 'lucide-react';

const ProducerDashboard = ({ user, token, axiosConfig }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  const [formData, setFormData] = useState({
    product_id: '',
    name: '',
    description: '',
    product_type: '',
    quantity: '',
    unit: 'kg',
    quality_grade: 'A',
    production_date: new Date().toISOString().split('T')[0],
    initial_price: ''
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/products/my-products`, axiosConfig);
      setProducts(response.data);
    } catch (error) {
      toast.error('Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingProduct) {
        await axios.put(`${API}/products/${editingProduct.id}`, formData, axiosConfig);
        toast.success('Product updated successfully');
      } else {
        await axios.post(`${API}/products`, formData, axiosConfig);
        toast.success('Product created successfully');
      }
      setShowAddDialog(false);
      setEditingProduct(null);
      resetForm();
      fetchProducts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    }
  };

  const handleDelete = async (productId) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;

    try {
      await axios.delete(`${API}/products/${productId}`, axiosConfig);
      toast.success('Product deleted successfully');
      fetchProducts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to delete product');
    }
  };

  const handleSubmitVerification = async (productId) => {
    try {
      await axios.post(`${API}/products/${productId}/submit-verification`, {}, axiosConfig);
      toast.success('Product submitted for verification');
      fetchProducts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to submit for verification');
    }
  };

  const resetForm = () => {
    setFormData({
      product_id: '',
      name: '',
      description: '',
      product_type: '',
      quantity: '',
      unit: 'kg',
      quality_grade: 'A',
      production_date: new Date().toISOString().split('T')[0],
      initial_price: ''
    });
  };

  const startEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      product_id: product.product_id,
      name: product.name,
      description: product.description,
      product_type: product.product_type,
      quantity: product.quantity,
      unit: product.unit,
      quality_grade: product.quality_grade,
      production_date: product.production_date,
      initial_price: product.initial_price
    });
    setShowAddDialog(true);
  };

  return (
    <div className="space-y-6">
      
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">My Products</h2>

        <Dialog 
          open={showAddDialog} 
          onOpenChange={(open) => {
            setShowAddDialog(open);
            if (!open) {
              setEditingProduct(null);
              resetForm();
            }
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" data-testid="add-product-btn">
              <Plus className="w-4 h-4 mr-2" />
              Add Product
            </Button>
          </DialogTrigger>

          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">

              <div>
                <Label htmlFor="product_id">Product ID / Batch Number</Label>
                <Input
                  id="product_id"
                  value={formData.product_id}
                  onChange={(e) => setFormData({ ...formData, product_id: e.target.value })}
                  required
                  placeholder="e.g., SKU-45291"
                />
              </div>

              <div>
                <Label htmlFor="name">Product Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="product_type">Product Type</Label>
                  <Input
                    id="product_type"
                    value={formData.product_type}
                    onChange={(e) => setFormData({ ...formData, product_type: e.target.value })}
                    required
                    placeholder="e.g., Organic Wheat"
                  />
                </div>

                <div>
                  <Label htmlFor="quality_grade">Quality Grade</Label>
                  <select
                    id="quality_grade"
                    value={formData.quality_grade}
                    onChange={(e) => setFormData({ ...formData, quality_grade: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300"
                  >
                    <option value="A">Grade A</option>
                    <option value="B">Grade B</option>
                    <option value="C">Grade C</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    step="0.01"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="unit">Unit</Label>
                  <select
                    id="unit"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300"
                  >
                    <option value="kg">Kilograms (kg)</option>
                    <option value="tons">Tons</option>
                    <option value="units">Units</option>
                    <option value="liters">Liters</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="production_date">Production Date</Label>
                  <Input
                    id="production_date"
                    type="date"
                    value={formData.production_date}
                    onChange={(e) => setFormData({ ...formData, production_date: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="initial_price">Initial Price ($)</Label>
                  <Input
                    id="initial_price"
                    type="number"
                    step="0.01"
                    value={formData.initial_price}
                    onChange={(e) => setFormData({ ...formData, initial_price: e.target.value })}
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                {editingProduct ? 'Update Product' : 'Add Product'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <p className="text-center text-gray-600">Loading products...</p>
      ) : products.length === 0 ? (
        <Card className="p-12 text-center">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 text-lg">No products yet. Add your first product!</p>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Card 
              key={product.id} 
              className="p-6 hover:shadow-lg transition-shadow"
              data-testid={`product-card-${product.id}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">

                  <p className="text-xs text-gray-500 mb-1 font-mono">
                    ID: {product.product_id}
                  </p>

                  <h3 className="text-xl font-bold text-gray-900 mb-1">{product.name}</h3>
                  <p className="text-sm text-gray-600">{product.product_type}</p>
                </div>

                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    product.verification_status === 'approved'
                      ? 'bg-green-100 text-green-700'
                      : product.verification_status === 'rejected'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}
                >
                  {product.verification_status}
                </span>
              </div>

              <p className="text-gray-700 mb-4 text-sm">{product.description}</p>

              <div className="space-y-2 mb-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Quantity:</span>
                  <span className="font-semibold">{product.quantity} {product.unit}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-gray-600">Grade:</span>
                  <span className="font-semibold">Grade {product.quality_grade}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-gray-600">Price:</span>
                  <span className="font-semibold text-emerald-600">
                    ${product.current_price ?? product.initial_price}
                  </span>
                </div>
              </div>

              <div className="flex space-x-2">
                {product.verification_status === 'pending' && (
                  <>
                    <Button
                      onClick={() => startEdit(product)}
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      data-testid={`edit-product-${product.id}`}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>

                    <Button
                      onClick={() => handleDelete(product.id)}
                      size="sm"
                      variant="outline"
                      className="border-red-200 text-red-600 hover:bg-red-50"
                      data-testid={`delete-product-${product.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>

                    <Button
                      onClick={() => handleSubmitVerification(product.id)}
                      size="sm"
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                      data-testid={`submit-verification-${product.id}`}
                    >
                      <Send className="w-4 h-4 mr-1" />
                      Submit
                    </Button>
                  </>
                )}

                {product.verification_status !== 'pending' && (
                  <div className="w-full text-center text-sm text-gray-500">
                    {product.verification_status === 'approved' 
                      ? 'Verified & Listed' 
                      : 'Verification Rejected'}
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProducerDashboard;
