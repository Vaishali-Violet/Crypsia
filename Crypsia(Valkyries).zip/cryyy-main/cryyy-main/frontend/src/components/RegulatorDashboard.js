import { useState, useEffect } from 'react';
import axios from 'axios';
import { API } from '../App';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner';
import { CheckCircle, XCircle, FileText } from 'lucide-react';

const RegulatorDashboard = ({ user, token, axiosConfig }) => {
  const [verifications, setVerifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedVerification, setSelectedVerification] = useState(null);
  const [notes, setNotes] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [actionType, setActionType] = useState('approve');

  useEffect(() => {
    fetchVerifications();
  }, []);

  const fetchVerifications = async () => {
    try {
      const response = await axios.get(`${API}/verifications/pending`, axiosConfig);
      setVerifications(response.data);
    } catch (error) {
      toast.error('Failed to fetch verifications');
    } finally {
      setLoading(false);
    }
  };

  const handleAction = (verification, action) => {
    setSelectedVerification(verification);
    setActionType(action);
    setNotes('');
    setShowDialog(true);
  };

  const submitAction = async () => {
    try {
      await axios.post(
        `${API}/verifications/process`,
        {
          verification_id: selectedVerification.id,
          action: actionType,
          notes: notes
        },
        axiosConfig
      );
      toast.success(`Product ${actionType}d successfully`);
      setShowDialog(false);
      fetchVerifications();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Action failed');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Pending Verifications</h2>

      {loading ? (
        <p className="text-center text-gray-600">Loading verifications...</p>
      ) : verifications.length === 0 ? (
        <Card className="p-12 text-center">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 text-lg">No pending verifications at the moment.</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {verifications.map((verification) => (
            <Card
              key={verification.id}
              className="p-6 hover:shadow-lg transition-shadow"
              data-testid={`verification-${verification.id}`}
            >
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{verification.product.name}</h3>

                  {/* Display Product ID */}
                  <p className="text-xs text-gray-500 mb-2 font-mono">
                    Product ID: {verification.product.product_id}
                  </p>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Producer:</span>
                      <span className="font-semibold">{verification.product.producer_name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Type:</span>
                      <span className="font-semibold">{verification.product.product_type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Quantity:</span>
                      <span className="font-semibold">
                        {verification.product.quantity} {verification.product.unit}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Quality Grade:</span>
                      <span className="font-semibold">Grade {verification.product.quality_grade}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price:</span>
                      <span className="font-semibold text-emerald-600">
                        ${verification.product.current_price ?? verification.product.initial_price}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Production Date:</span>
                      <span className="font-semibold">{verification.product.production_date}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                  <p className="text-gray-700 text-sm mb-4">{verification.product.description}</p>

                  <div className="flex space-x-3">
                    <Button
                      onClick={() => handleAction(verification, 'approve')}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      data-testid={`approve-${verification.id}`}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approve
                    </Button>
                    <Button
                      onClick={() => handleAction(verification, 'reject')}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                      data-testid={`reject-${verification.id}`}
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === 'approve' ? 'Approve' : 'Reject'} Product Verification
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-gray-700">
              Are you sure you want to {actionType} <strong>{selectedVerification?.product?.name}</strong>?
            </p>

            <div>
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                placeholder="Add verification notes..."
                data-testid="verification-notes"
              />
            </div>

            <div className="flex space-x-3">
              <Button
                onClick={submitAction}
                className={`flex-1 ${actionType === 'approve' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                data-testid="confirm-action-btn"
              >
                Confirm {actionType === 'approve' ? 'Approval' : 'Rejection'}
              </Button>

              <Button
                onClick={() => setShowDialog(false)}
                variant="outline"
                className="flex-1"
                data-testid="cancel-action-btn"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RegulatorDashboard;
