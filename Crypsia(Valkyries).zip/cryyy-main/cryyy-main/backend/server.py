# (full file) server.py
from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import hashlib
import jwt
from passlib.context import CryptContext
import json

ROOT_DIR = Path(_file_).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.environ.get('SECRET_KEY', 'crypsia-secret-key-change-in-production')
ALGORITHM = "HS256"
security = HTTPBearer()

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# Models
class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: str  # producer, regulator, distributor, retailer, consumer
    contact: str
    location: Optional[str] = None
    product_type: Optional[str] = None  # For producers
    payment_info: Optional[str] = None
    terms_accepted: bool

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    full_name: str
    role: str
    contact: str
    location: Optional[str] = None
    product_type: Optional[str] = None
    payment_info: Optional[str] = None
    wallet_balance: float = 10000.0  # Mock wallet balance
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    product_id: str  # Custom product ID entered by producer
    producer_id: str
    producer_name: str
    name: str
    description: str
    product_type: str
    quantity: float
    unit: str
    quality_grade: str
    production_date: str
    initial_price: float
    current_price: float
    current_owner_id: str
    current_owner_role: str
    status: str  # pending, verified, in_transit, sold
    verification_status: str  # pending, approved, rejected
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductCreate(BaseModel):
    product_id: str  # Custom product ID (e.g., SKU, barcode, batch number)
    name: str
    description: str
    product_type: str
    quantity: float
    unit: str
    quality_grade: str
    production_date: str
    initial_price: float

class VerificationRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    product_id: str
    producer_id: str
    regulator_id: Optional[str] = None
    status: str  # pending, approved, rejected
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    processed_at: Optional[datetime] = None

class VerificationAction(BaseModel):
    verification_id: str
    action: str  # approve, reject
    notes: Optional[str] = None

class procurementTransaction(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    transaction_hash: str
    transaction_type: str  # verification, purchase, price_update, transfer
    from_user_id: str
    from_user_name: str
    from_user_role: str
    to_user_id: Optional[str] = None
    to_user_name: Optional[str] = None
    to_user_role: Optional[str] = None
    product_id: str
    product_name: str
    amount: float
    price: float
    previous_hash: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = {}

class PurchaseRequest(BaseModel):
    product_id: str
    buyer_role: str  # distributor, retailer, consumer

class PriceUpdate(BaseModel):
    product_id: str
    new_price: float

class Payment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    from_user_id: str
    to_user_id: str
    amount: float
    payment_type: str  # mock_crypto, mock_fiat
    status: str  # pending, completed, failed
    transaction_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Helper Functions
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(days=7)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def create_procurement_hash(data: dict, previous_hash: Optional[str] = None) -> str:
    """Create SHA-256 hash for procurement simulation"""
    hash_data = json.dumps(data, sort_keys=True, default=str)
    if previous_hash:
        hash_data = previous_hash + hash_data
    return hashlib.sha256(hash_data.encode()).hexdigest()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return User(**user)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except Exception as e:
        raise HTTPException(status_code=401, detail="Invalid authentication")

async def get_last_procurement_hash() -> Optional[str]:
    """Get the last transaction hash for procurement chain continuity"""
    last_tx = await db.procurement_transactions.find_one(
        {}, {"_id": 0, "transaction_hash": 1}, sort=[("timestamp", -1)]
    )
    return last_tx["transaction_hash"] if last_tx else None

# API Routes
@api_router.post("/auth/register")
async def register(user_data: UserRegister):
    # Check if user exists
    existing = await db.users.find_one({"email": user_data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    if not user_data.terms_accepted:
        raise HTTPException(status_code=400, detail="Must accept terms and conditions")
    
    # Create user
    user_dict = user_data.model_dump(exclude={"password", "terms_accepted"})
    user = User(**user_dict)
    
    doc = user.model_dump()
    doc["password_hash"] = hash_password(user_data.password)
    doc["created_at"] = doc["created_at"].isoformat()
    
    await db.users.insert_one(doc)
    
    token = create_access_token({"user_id": user.id, "email": user.email, "role": user.role})
    
    return {
        "message": "Registration successful",
        "token": token,
        "user": user.model_dump()
    }

@api_router.post("/auth/login")
async def login(login_data: UserLogin):
    user_doc = await db.users.find_one({"email": login_data.email}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not verify_password(login_data.password, user_doc["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    user = User(**user_doc)
    token = create_access_token({"user_id": user.id, "email": user.email, "role": user.role})
    
    return {
        "message": "Login successful",
        "token": token,
        "user": user.model_dump()
    }

@api_router.get("/auth/me")
async def get_me(current_user: User = Depends(get_current_user)):
    # Refresh wallet balance from database
    user_doc = await db.users.find_one({"id": current_user.id}, {"_id": 0})
    return User(**user_doc).model_dump()

# Producer Routes
@api_router.post("/products", response_model=Product)
async def create_product(product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    if current_user.role != "producer":
        raise HTTPException(status_code=403, detail="Only producers can create products")
    
    product_dict = product_data.model_dump()
    # Defensive: ensure product_id exists (ProductCreate requires it)
    product_dict["product_id"] = product_dict.get("product_id") or str(uuid.uuid4())
    product = Product(
        **product_dict,
        producer_id=current_user.id,
        producer_name=current_user.full_name,
        current_price=product_data.initial_price,
        current_owner_id=current_user.id,
        current_owner_role="producer",
        status="pending",
        verification_status="pending"
    )
    
    doc = product.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    
    await db.products.insert_one(doc)
    
    return product

@api_router.get("/products/my-products", response_model=List[Product])
async def get_my_products(current_user: User = Depends(get_current_user)):
    if current_user.role == "producer":
        products = await db.products.find({"producer_id": current_user.id}, {"_id": 0}).to_list(1000)
    else:
        products = await db.products.find({"current_owner_id": current_user.id}, {"_id": 0}).to_list(1000)
    
    for p in products:
        if isinstance(p.get("created_at"), str):
            p["created_at"] = datetime.fromisoformat(p["created_at"])
        # Defensive: map possible product id fields to product_id
        p["product_id"] = p.get("product_id") or p.get("productId") or p.get("id") or ""
    
    return products

@api_router.delete("/products/{product_id}")
async def delete_product(product_id: str, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if product["producer_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    if product["verification_status"] != "pending":
        raise HTTPException(status_code=400, detail="Cannot delete verified products")
    
    await db.products.delete_one({"id": product_id})
    return {"message": "Product deleted successfully"}

@api_router.put("/products/{product_id}")
async def update_product(product_id: str, product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if product["producer_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    if product["verification_status"] != "pending":
        raise HTTPException(status_code=400, detail="Cannot edit verified products")
    
    update_data = product_data.model_dump()
    update_data["current_price"] = product_data.initial_price
    # Ensure product_id stays (it's part of update_data from ProductCreate)
    update_data["product_id"] = update_data.get("product_id") or product.get("product_id") or product.get("id")
    
    await db.products.update_one({"id": product_id}, {"$set": update_data})
    
    updated_product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if isinstance(updated_product.get("created_at"), str):
        updated_product["created_at"] = datetime.fromisoformat(updated_product["created_at"])
    updated_product["product_id"] = updated_product.get("product_id") or updated_product.get("id")
    
    return Product(**updated_product)

@api_router.post("/products/{product_id}/submit-verification")
async def submit_for_verification(product_id: str, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if product["producer_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    # Create verification request
    verification = VerificationRequest(
        product_id=product_id,
        producer_id=current_user.id,
        status="pending"
    )
    
    doc = verification.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    
    await db.verification_requests.insert_one(doc)
    
    return {"message": "Product submitted for verification", "verification_id": verification.id}

# Regulator Routes
@api_router.get("/verifications/pending", response_model=List[Dict])
async def get_pending_verifications(current_user: User = Depends(get_current_user)):
    if current_user.role != "regulator":
        raise HTTPException(status_code=403, detail="Only regulators can access this")
    
    verifications = await db.verification_requests.find(
        {"status": "pending"}, {"_id": 0}
    ).to_list(1000)
    
    result = []
    for v in verifications:
        if isinstance(v.get("created_at"), str):
            v["created_at"] = datetime.fromisoformat(v["created_at"])
        
        product = await db.products.find_one({"id": v["product_id"]}, {"_id": 0})
        if product:
            # Ensure created_at conversion and product_id presence
            if isinstance(product.get("created_at"), str):
                product["created_at"] = datetime.fromisoformat(product["created_at"])
            # Defensive: normalize product_id field
            product["product_id"] = product.get("product_id") or product.get("productId") or product.get("id") or ""
            v["product"] = product
            result.append(v)
    
    return result

@api_router.post("/verifications/process")
async def process_verification(action: VerificationAction, current_user: User = Depends(get_current_user)):
    if current_user.role != "regulator":
        raise HTTPException(status_code=403, detail="Only regulators can verify products")
    
    verification = await db.verification_requests.find_one({"id": action.verification_id}, {"_id": 0})
    if not verification:
        raise HTTPException(status_code=404, detail="Verification request not found")
    
    product = await db.products.find_one({"id": verification["product_id"]}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Update verification
    await db.verification_requests.update_one(
        {"id": action.verification_id},
        {"$set": {
            "status": action.action + "d",
            "regulator_id": current_user.id,
            "notes": action.notes,
            "processed_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    # *** FIX: When updating product, explicitly preserve product_id and ensure owner remains producer.
    new_status = "verified" if action.action == "approve" else "rejected"
    await db.products.update_one(
        {"id": verification["product_id"]},
        {"$set": {
            "verification_status": action.action + "d",
            "status": new_status,
            # keep owner as producer so product is visible in marketplace for distributors
            "current_owner_id": product.get("producer_id", product.get("current_owner_id")),
            "current_owner_role": "producer",
            # ensure product_id remains (defensive)
            "product_id": product.get("product_id") or product.get("id")
        }}
    )
    
    if action.action == "approve":
        # Create procurement transaction
        previous_hash = await get_last_procurement_hash()
        
        tx_data = {
            "transaction_type": "verification",
            "from_user_id": current_user.id,
            "from_user_name": current_user.full_name,
            "from_user_role": "regulator",
            "to_user_id": product["producer_id"],
            "to_user_name": product["producer_name"],
            "to_user_role": "producer",
            # Use the public product_id for traceability
            "product_id": product.get("product_id", product["id"]),
            "product_name": product["name"],
            "amount": 0,
            "price": product["current_price"],
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metadata": {"quality_grade": product.get("quality_grade"), "verification_notes": action.notes}
        }
        
        tx_hash = create_procurement_hash(tx_data, previous_hash)
        
        procurement_tx = procurementTransaction(
            transaction_hash=tx_hash,
            previous_hash=previous_hash,
            **tx_data
        )
        
        doc = procurement_tx.model_dump()
        doc["timestamp"] = doc["timestamp"].isoformat() if isinstance(doc["timestamp"], datetime) else doc["timestamp"]
        await db.procurement_transactions.insert_one(doc)
        
        # Simulate payment to producer (verification fee deducted)
        regulator_fee = product["current_price"] * 0.02
        producer_payment = product["current_price"] - regulator_fee
        
        # Update balances
        await db.users.update_one(
            {"id": product["producer_id"]},
            {"$inc": {"wallet_balance": producer_payment}}
        )
        await db.users.update_one(
            {"id": current_user.id},
            {"$inc": {"wallet_balance": regulator_fee}}
        )
        
        # Record payments
        payment_tx = Payment(
            from_user_id="system",
            to_user_id=product["producer_id"],
            amount=producer_payment,
            payment_type="mock_fiat",
            status="completed",
            transaction_id=tx_hash
        )
        payment_doc = payment_tx.model_dump()
        payment_doc["created_at"] = payment_doc["created_at"].isoformat()
        await db.payments.insert_one(payment_doc)
    
    return {"message": f"Product {action.action}d successfully"}

# Distributor/Retailer Routes
@api_router.get("/marketplace/products", response_model=List[Product])
async def get_marketplace_products(current_user: User = Depends(get_current_user)):
    query = {"verification_status": "approved"}
    
    # Show products based on role
    if current_user.role == "distributor":
        query["current_owner_role"] = "producer"
    elif current_user.role == "retailer":
        query["current_owner_role"] = "distributor"
    elif current_user.role == "consumer":
        query["current_owner_role"] = "retailer"
    else:
        raise HTTPException(status_code=403, detail="Invalid role for marketplace")
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    
    for p in products:
        if isinstance(p.get("created_at"), str):
            p["created_at"] = datetime.fromisoformat(p["created_at"])
        # Defensive: normalize product_id field so frontend always gets product_id
        p["product_id"] = p.get("product_id") or p.get("productId") or p.get("id") or ""
    
    return products

@api_router.post("/marketplace/purchase")
async def purchase_product(purchase: PurchaseRequest, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": purchase.product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if product["current_owner_id"] == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot purchase your own product")
    
    # Check wallet balance
    buyer = await db.users.find_one({"id": current_user.id}, {"_id": 0})
    if buyer["wallet_balance"] < product["current_price"]:
        raise HTTPException(status_code=400, detail="Insufficient wallet balance")
    
    # Process transaction
    previous_hash = await get_last_procurement_hash()
    
    # Get seller info
    seller = await db.users.find_one({"id": product["current_owner_id"]}, {"_id": 0})
    
    tx_data = {
        "transaction_type": "purchase",
        "from_user_id": current_user.id,
        "from_user_name": current_user.full_name,
        "from_user_role": current_user.role,
        "to_user_id": product["current_owner_id"],
        "to_user_name": seller["full_name"],
        "to_user_role": product["current_owner_role"],
        # For traceability include the public product_id (batch/SKU) if available, otherwise internal id
        "product_id": product.get("product_id", product["id"]),
        "product_name": product["name"],
        "amount": product["current_price"],
        "price": product["current_price"],
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "metadata": {"quantity": product["quantity"], "unit": product["unit"]}
    }
    
    tx_hash = create_procurement_hash(tx_data, previous_hash)
    
    procurement_tx = procurementTransaction(
        transaction_hash=tx_hash,
        previous_hash=previous_hash,
        **tx_data
    )
    
    doc = procurement_tx.model_dump()
    doc["timestamp"] = doc["timestamp"].isoformat() if isinstance(doc["timestamp"], datetime) else doc["timestamp"]
    await db.procurement_transactions.insert_one(doc)
    
    # Update balances
    await db.users.update_one(
        {"id": current_user.id},
        {"$inc": {"wallet_balance": -product["current_price"]}}
    )
    await db.users.update_one(
        {"id": product["current_owner_id"]},
        {"$inc": {"wallet_balance": product["current_price"]}}
    )
    
    # Transfer ownership - preserve product_id and set new owner fields
    await db.products.update_one(
        {"id": purchase.product_id},
        {"$set": {
            "current_owner_id": current_user.id,
            "current_owner_role": current_user.role,
            "status": "in_transit",
            # defensive: ensure product_id remains present on the document
            "product_id": product.get("product_id", product["id"])
        }}
    )
    
    # Record payment
    payment_tx = Payment(
        from_user_id=current_user.id,
        to_user_id=product["current_owner_id"],
        amount=product["current_price"],
        payment_type="mock_fiat",
        status="completed",
        transaction_id=tx_hash
    )
    payment_doc = payment_tx.model_dump()
    payment_doc["created_at"] = payment_doc["created_at"].isoformat()
    await db.payments.insert_one(payment_doc)
    
    return {"message": "Purchase successful", "transaction_hash": tx_hash}

@api_router.post("/marketplace/update-price")
async def update_product_price(price_update: PriceUpdate, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": price_update.product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if product["current_owner_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    # Create procurement record for price update
    previous_hash = await get_last_procurement_hash()
    
    tx_data = {
        "transaction_type": "price_update",
        "from_user_id": current_user.id,
        "from_user_name": current_user.full_name,
        "from_user_role": current_user.role,
        "product_id": product.get("product_id", product["id"]),
        "product_name": product["name"],
        "amount": 0,
        "price": price_update.new_price,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "metadata": {"old_price": product["current_price"], "new_price": price_update.new_price}
    }
    
    tx_hash = create_procurement_hash(tx_data, previous_hash)
    
    procurement_tx = procurementTransaction(
        transaction_hash=tx_hash,
        previous_hash=previous_hash,
        **tx_data
    )
    
    doc = procurement_tx.model_dump()
    doc["timestamp"] = doc["timestamp"].isoformat() if isinstance(doc["timestamp"], datetime) else doc["timestamp"]
    await db.procurement_transactions.insert_one(doc)
    
    # Update product price - ensure product_id remains intact
    await db.products.update_one(
        {"id": price_update.product_id},
        {"$set": {"current_price": price_update.new_price, "product_id": product.get("product_id", product["id"])}}
    )
    
    return {"message": "Price updated successfully", "transaction_hash": tx_hash}

# Consumer Routes
@api_router.get("/products/{product_id}/verify")
async def verify_product(product_id: str):
    """Get complete procurement history for a product"""
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Get all procurement transactions for this product
    transactions = await db.procurement_transactions.find(
        {"product_id": product_id}, {"_id": 0}
    ).sort("timestamp", 1).to_list(1000)
    
    for tx in transactions:
        if isinstance(tx.get("timestamp"), str):
            tx["timestamp"] = datetime.fromisoformat(tx["timestamp"])
    
    if isinstance(product.get("created_at"), str):
        product["created_at"] = datetime.fromisoformat(product["created_at"])
    
    # Defensive: ensure product_id is present in response
    product["product_id"] = product.get("product_id") or product.get("id")
    
    return {
        "product": product,
        "procurement_history": transactions,
        "verified": product.get("verification_status") == "approved"
    }

# Admin helper: fix missing product_id fields (run once if you have older records)
@api_router.post("/admin/fix-product-ids")
async def fix_product_ids(current_user: User = Depends(get_current_user)):
    """
    Backfill product_id for product documents missing it.
    This sets product_id = id for any product without product_id.
    Run once and remove or protect this endpoint afterward.
    """
    # Optional: restrict to admin/regulator (simple check)
    if current_user.role not in ["regulator", "producer"]:
        # allow regulators/producers to run; modify as needed
        raise HTTPException(status_code=403, detail="Not authorized")
    
    cursor = db.products.find({"$or": [{"product_id": {"$exists": False}}, {"product_id": ""}]}, {"_id": 0})
    updated = 0
    async for p in cursor:
        pid = p.get("id")
        if pid:
            await db.products.update_one({"id": pid}, {"$set": {"product_id": pid}})
            updated += 1
    return {"message": "Backfill completed", "updated": updated}

# Transaction Ledger
@api_router.get("/transactions", response_model=List[procurementTransaction])
async def get_all_transactions(current_user: User = Depends(get_current_user)):
    transactions = await db.procurement_transactions.find(
        {}, {"_id": 0}
    ).sort("timestamp", -1).to_list(1000)
    
    for tx in transactions:
        if isinstance(tx.get("timestamp"), str):
            tx["timestamp"] = datetime.fromisoformat(tx["timestamp"])
    
    return transactions

@api_router.get("/transactions/my-transactions", response_model=List[procurementTransaction])
async def get_my_transactions(current_user: User = Depends(get_current_user)):
    transactions = await db.procurement_transactions.find(
        {"$or": [
            {"from_user_id": current_user.id},
            {"to_user_id": current_user.id}
        ]},
        {"_id": 0}
    ).sort("timestamp", -1).to_list(1000)
    
    for tx in transactions:
        if isinstance(tx.get("timestamp"), str):
            tx["timestamp"] = datetime.fromisoformat(tx["timestamp"])
    
    return transactions

# Analytics
@api_router.get("/analytics/dashboard")
async def get_dashboard_analytics(current_user: User = Depends(get_current_user)):
    if current_user.role == "producer":
        products_count = await db.products.count_documents({"producer_id": current_user.id})
        verified_count = await db.products.count_documents({
            "producer_id": current_user.id,
            "verification_status": "approved"
        })
        
        transactions = await db.procurement_transactions.find(
            {"to_user_id": current_user.id}, {"_id": 0}
        ).to_list(1000)
        total_revenue = sum(tx["amount"] for tx in transactions)
        
        return {
            "total_products": products_count,
            "verified_products": verified_count,
            "total_revenue": total_revenue,
            "wallet_balance": current_user.wallet_balance
        }
    
    elif current_user.role == "regulator":
        pending_verifications = await db.verification_requests.count_documents({"status": "pending"})
        completed_verifications = await db.verification_requests.count_documents({
            "regulator_id": current_user.id
        })
        
        return {
            "pending_verifications": pending_verifications,
            "completed_verifications": completed_verifications,
            "wallet_balance": current_user.wallet_balance
        }
    
    elif current_user.role in ["distributor", "retailer"]:
        owned_products = await db.products.count_documents({"current_owner_id": current_user.id})
        
        purchase_txs = await db.procurement_transactions.find(
            {"from_user_id": current_user.id, "transaction_type": "purchase"},
            {"_id": 0}
        ).to_list(1000)
        total_spent = sum(tx["amount"] for tx in purchase_txs)
        
        sales_txs = await db.procurement_transactions.find(
            {"to_user_id": current_user.id, "transaction_type": "purchase"},
            {"_id": 0}
        ).to_list(1000)
        total_revenue = sum(tx["amount"] for tx in sales_txs)
        
        return {
            "owned_products": owned_products,
            "total_spent": total_spent,
            "total_revenue": total_revenue,
            "profit": total_revenue - total_spent,
            "wallet_balance": current_user.wallet_balance
        }
    
    elif current_user.role == "consumer":
        purchases = await db.procurement_transactions.count_documents({
            "from_user_id": current_user.id,
            "transaction_type": "purchase"
        })
        
        purchase_txs = await db.procurement_transactions.find(
            {"from_user_id": current_user.id, "transaction_type": "purchase"},
            {"_id": 0}
        ).to_list(1000)
        total_spent = sum(tx["amount"] for tx in purchase_txs)
        
        return {
            "total_purchases": purchases,
            "total_spent": total_spent,
            "wallet_balance": current_user.wallet_balance
        }
    
    return {}

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(_name_)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()